const animals = ["anjing", "kucing", "domba"];

// Ganti element ketiga dari array menjadi "kelinci"
animals[2]="kelinci";

// Cetak array ketiga dari constant animal ke console
console.log(animals[2]);
