// Gunakan loop for untuk mencetak angka dari 1 hingga 100

for(let number=1;number<=100;number++){
  console.log(number);
}