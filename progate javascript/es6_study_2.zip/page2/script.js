// Deklarasikan variable number
let number =1;

// Tambahkan while loop di bawah
while(number<=100){
  
  console.log(number);
  number+=1;
}
