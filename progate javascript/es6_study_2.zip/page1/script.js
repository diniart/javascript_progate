// Deklarasikan variable number
let number = 1;

// Print nilai dari variable number, dan tambahkan dengan 1
console.log(number);
number += 1;

// Salin kedua baris diatas dan tempelkan dibaris bawah sebanyak 4 kali
console.log(number);
number += 1;

console.log(number);
number += 1;

console.log(number);
number += 1;

console.log(number);
number += 1;
