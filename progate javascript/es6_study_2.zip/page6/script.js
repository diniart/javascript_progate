const animals = ["anjing", "kucing", "domba"];

// Cetak element array pertama
console.log(animals[0]);

// Cetak element array ketiga
console.log(animals[2]);