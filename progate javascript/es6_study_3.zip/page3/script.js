// Tetapkan arrow function ke constant greet

const greet = ()=>{
  console.log("Halo!");
}

// Panggil function greet

greet();