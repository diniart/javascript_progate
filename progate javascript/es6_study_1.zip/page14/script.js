const password = "ninjaken";

// Ketika nilai password adalah "ninjaken", cetak "Berhasil log in"
if(password === "ninjaken"){
  console.log("Berhasil log in");
}

// Ketika nilai password bukan "ninjaken", cetak "Password salah"
if(password !== "ninjaken"){
  console.log("Password salah");
}