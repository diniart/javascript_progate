



// Code di bawah jangan diganggu karena bukan bagian dari class Animal ataupun Dog
const dog = new Dog("Leo", 4, "Chihuahua");
dog.info();
