// Hapus code di bawah

// Hapus code di atas

// Import constant dog
import dog from './dogData';

dog.info();